package com.cs3251.protocol;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.util.Scanner;

public class ProtocolClientTester {
	private static short clientPort;
	private static short netEmuPort;
	private static InetAddress ipAddress;
	
	public static void main(String args[]) throws ClassNotFoundException, IOException{
	//	short clientPort = 15888;
	//	short serverPort = 15889;
		
		if (args.length!=4||!args[0].equals("FxA-client")){
			System.out.println("The arguments entered were invalid. Exiting.");
			System.exit(0);
		}
		try{
			clientPort = Short.parseShort(args[1]);
		}
		catch(NumberFormatException ex){
			System.out.println("Port number must be an int. Exiting.");
			System.exit(0);
		}
		try{
			ipAddress = InetAddress.getByName(args[2]);
		}
		catch(UnknownHostException ex){
			System.out.println("IP Address was invalid. Exiting.");
			System.exit(0);
		}
		try{
			netEmuPort = Short.parseShort(args[3]);
		}
		catch(NumberFormatException ex){
			System.out.println("Port number was invalid. Exiting.");
			System.exit(0);
		}
		
		RxPClient client = new RxPClient("localhost", "localhost", clientPort, netEmuPort);
		
		//client.connect();
		Scanner scan = new Scanner(System.in);
		boolean run = true;
		while(run){
			String nextLine = scan.nextLine();
			if (nextLine.length()<=10){
				String[] input = nextLine.split(" ");
				if (input.length==1){
					if(nextLine.equals("connect")){
						client.connect();
					}
					else if (nextLine.equals("disconnect")){
						client.close();
						run = false;
					}
					else{
						System.out.println("Invalid input.");
					}
				}
				
				else if (input.length==2){
					if (input[0].equals("get")){
						String filename = input[1];
						String request = "GET*"+filename;
						byte[] ret = client.getData(request.getBytes());
						if (ret.length!=0){
							FileOutputStream fos = new FileOutputStream("filename");
							fos.write(ret);
							fos.close();
							System.out.println("Successful GET.");
						}
						else{
							System.out.println("Unsuccessful GET.");
						}
					}
					else if(input[0].equals("post")){ // upload file to server
						String filename = input[1];
						byte[] rqst = client.getData(("POST*"+filename).getBytes());
						if (rqst.toString().equals("!")){
							String fRqst = System.getProperty("user.dir")+filename;
							System.out.println("Searching for filepath: "+fRqst);
							File f = new File(fRqst);
							if (f.exists()){
								byte[] fileIn = new byte[Files.readAllBytes(f.toPath()).length];
								fileIn = Files.readAllBytes(f.toPath());
								client.sendData(fileIn);
							}
							else{
								System.out.println("File was not found.");
								client.sendData(new byte[0]);
							}
						}
						else{
							
						}
					}
					else if(input[0].equals("window")){
						// call client set window method
						//int size = Integer.parseInt(input[1]);
						//client.setWindow(size);
					}
					else{
						System.out.println("Invalid input.");
					}
				}
			}
			else{
				System.out.println("Invalid input.");
			}
		}
	}
}
